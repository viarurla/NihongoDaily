CREATE VIEW entries_v as
    select
           e.id as entry_id,
        GROUP_CONCAT(distinct(k.value)) as kana,
        katk.value as kanji,
        GROUP_CONCAT(distinct(d.value)) as definition,
        m.value as misc
    from entry e
    left join kana k on e.id = k.entry_id
    left join kana_applies_to_kanji katk on k.id = katk.kana_id
    left join sense s on e.id = s.entry_id
    left join definition d on s.id = d.sense_id
    left join misc m on s.id = m.sense_id
    group by e.id;

